<template>
    <p>
        Оплата по карте курьеру при получении заказа
    </p>    
</template>

<script lang="ts">
import { defineComponent } from "@vue/runtime-core";

export default defineComponent({
    
});
</script>