<template>
    <div>
        Оплата наличными курьеру при получении заказа
    </div>
</template>

<script lang="ts">
import { defineComponent } from "@vue/runtime-core";

export default defineComponent({
    
});
</script>