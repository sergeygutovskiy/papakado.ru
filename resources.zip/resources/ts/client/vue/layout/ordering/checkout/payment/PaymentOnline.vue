<template>
    <p>
        После подтвержения заказа, вы будете перенаправлены на страницу оплаты
    </p>
</template>

<script lang="ts">
import { defineComponent } from "@vue/runtime-core";

export default defineComponent({
    
});
</script>