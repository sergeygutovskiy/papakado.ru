<template>
    <div>
        Оплата наличными или по карте при получении заказа в ресторане
    </div>
</template>

<script lang="ts">
import { defineComponent } from "@vue/runtime-core";

export default defineComponent({
    
});
</script>