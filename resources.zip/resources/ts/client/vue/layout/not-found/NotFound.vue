<template>
    <section>
        <header class="main-section__header">
            <h1 class="main-section__title">
                Страница не найдена
            </h1>
        </header>
    </section>
</template>

<script lang="ts">
import { defineComponent } from "@vue/runtime-core";

export default defineComponent({

});
</script>