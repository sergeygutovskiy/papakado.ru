enum PaymentEnum {
    ONLINE = 'online',
    COURIER_CARD = 'courier-card',
    COURIER_CASH = 'courier-cash',
    IN_PLACE = 'in_place',
}

export default PaymentEnum;