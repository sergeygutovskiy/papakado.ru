enum DeliveryEnum {
    COURIER = 'courier',
    PICKUP = 'pickup',
}

export default DeliveryEnum;