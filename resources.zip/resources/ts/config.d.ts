declare module "*.vue" {
    import { defineComponent } from "@vue/runtime-core";
    export default defineComponent;
}