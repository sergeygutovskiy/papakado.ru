<template>
    
</template>

<script lang="ts">
import { defineComponent } from "@vue/runtime-core";

export default defineComponent({
})
</script>
