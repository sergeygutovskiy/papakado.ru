<template>
    <div>
        Оплата наличными или по карте при получении заказа в ресторане
    </div>
</template>

<script>
export default {
    
}
</script>