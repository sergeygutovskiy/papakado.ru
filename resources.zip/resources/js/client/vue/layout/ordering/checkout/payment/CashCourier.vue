<template>
    <div>
        Оплата наличными курьеру при получении заказа
    </div>
</template>

<script>
export default {
    
}
</script>