<template>
    <p>
        Оплата по карте курьеру при получении заказа
    </p>
</template>

<script>
export default {
    
}
</script>