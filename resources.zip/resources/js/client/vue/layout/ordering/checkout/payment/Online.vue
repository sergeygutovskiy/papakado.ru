<template>
    <p>
        После подтвержения заказа, вы будете перенаправлены на страницу оплаты
    </p>
</template>

<script>
export default {
    
}
</script>