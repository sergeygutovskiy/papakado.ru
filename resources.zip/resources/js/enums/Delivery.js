const DeliveryEnum = Object.freeze({
    PICKUP  : { slug: "pickup"  },
    COURIER : { slug: "courier" }
});

export default DeliveryEnum;