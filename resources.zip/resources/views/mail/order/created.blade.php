<div>
    <p> 
        <a href="https://papakado.ru/admin/orders/{{ $order->id }}">Посмотреть</a> 
    </p>
</div>